#include "pch.h"
#include "Sphere_UV.h"

bool Sphere_UV::HitUV(const Ray& ray, HitRecordTex& hitRecordTex) const
{
	const FVector3 L = m_Position - ray.origin;

	const float tca = Dot(L, ray.direction);

	const float dotL = Dot(L, L);

	const float od2 = dotL - (tca * tca);
	const float rad2 = m_Radius * m_Radius;

	if (od2 > rad2)
		return false;
	// if the od squared is greater than the radius squared, the point will be outside of the sphere/circle

	const float thc2 = rad2 - od2;

	const float thc = sqrtf(thc2);

	const float t = tca - thc;
	if (t < tMin || t > tMax)
		return false;

	const float A{ Dot(ray.direction, ray.direction) };
	if (A < 0)
		return false;
	const float B{ tca };
	const float C{ dotL - rad2 };
	const float discriminant{ (B * B) - (A * C) };

	if (discriminant > 0)
	{
		hitRecordTex.t = t;
		hitRecordTex.point = ray.origin + hitRecordTex.t * ray.direction;
		hitRecordTex.normal = (hitRecordTex.point - m_Position) / m_Radius;
		//hitRecord.normal = hitRecord.point - m_Position;
		//Elite::Normalize(hitRecord.normal);
		hitRecordTex.pMaterial = m_pMaterial;
		hitRecordTex.pTexture = m_pTexture;
		return true;
	}
	return false;
}