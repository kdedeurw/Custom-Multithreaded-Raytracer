#pragma once
#include "Object.h"

class Sphere : public Object
{
public:
	explicit Sphere(const Elite::FPoint3& point, float radius, Material* pMaterial);
	virtual ~Sphere() = default;

	virtual bool Hit(const Ray& ray, HitRecord& hitRecord) const override;

	const float GetRadius() const;

protected:
	float m_Radius;
};