#pragma once
#include "Material.h"

class Material_Reflect : public Material
{
public:
	Material_Reflect(const Elite::RGBColor& diffuseColour, float diffuseReflectance);
	virtual ~Material_Reflect() = default;

	virtual Elite::RGBColor Shade(Object* pObject, const HitRecord& hitRecord, const Elite::FVector3& lightDir, const Elite::FVector3& viewDir) const override;

protected:
};