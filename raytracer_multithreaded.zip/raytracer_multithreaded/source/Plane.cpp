#include "pch.h"
#include "Plane.h"
#include "HitRecord.h"
#include "Ray.h"

using namespace Elite;

Plane::Plane(const FPoint3& point, const FVector3& normal, Material* pMaterial)
	: Object{point, pMaterial}
	, m_Normal{normal}
{}

bool Plane::Hit(const Ray& ray, HitRecord& hitRecord) const
{
	if (Dot(ray.direction, m_Normal) > 0)
	{
		return false;
	}

	const float t = Elite::Dot(FVector3{ m_Position - ray.origin }, m_Normal) / Elite::Dot(ray.direction, m_Normal);

	if (t > RayData::tMin && t < RayData::tMax)
	{
		hitRecord.t = t;
		hitRecord.point = ray.origin + hitRecord.t * ray.direction;
		hitRecord.normal = m_Normal;
		hitRecord.pMaterial = m_pMaterial;
		return true;
	}
	return false;
}

const Elite::FVector3& Plane::GetNormal() const
{
	return m_Normal;
}