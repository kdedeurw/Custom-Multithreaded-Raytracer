#include "pch.h"
#include "Light.h"

using namespace Elite;

Light::Light(const RGBColor& colour, float intensity)
	: m_Colour{colour}
	, m_Intensity{intensity}
{}