#pragma once
#include "SDL.h"
#include <vector>

class EventManager final
{
public:
	static EventManager* GetInstance()
	{
		if (!m_pEventManager) m_pEventManager = new EventManager{};
		return m_pEventManager;
	}
	virtual ~EventManager();

	bool ProcessInputs(float deltaTime, bool& takeScreenshot);
	void GetMouseButtonsClicked(bool& lmb, bool& rmb, bool& m3);
	int GetScrollWheelValue() const;

	void GetRelativeMouseValues(float& x, float& y);

private:
	static EventManager* m_pEventManager;
	EventManager() = default;

	bool m_IsRelativeMouse = true;
	bool m_IsLMB = false, m_IsRMB = false, m_IsMouse3 = false;
	int m_ScrollWheelValue = 0;

	void KeyDownEvent(const SDL_KeyboardEvent& e);
	void KeyUpEvent(const SDL_KeyboardEvent& e);
	void MouseMotionEvent(const SDL_MouseButtonEvent& e);
	void MouseDownEvent(const SDL_MouseButtonEvent& e);
	void MouseUpEvent(const SDL_MouseButtonEvent& e);
	void MouseWheelEvent(const SDL_MouseWheelEvent& e);
};