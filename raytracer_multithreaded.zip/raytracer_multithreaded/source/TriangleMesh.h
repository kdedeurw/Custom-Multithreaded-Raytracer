#pragma once
#include <string>
#include <vector>
#include "Object.h"

struct BaseVertex;
class TriangleMesh : public Object
{
public:
	enum class Cullmode
	{
		backface,
		frontface,
		noculling
	};

	explicit TriangleMesh(const Elite::FPoint3& pos, Material* pMaterial, const std::string& objPath);
	~TriangleMesh() = default;

	virtual bool Hit(const Ray& ray, HitRecord& hitRecord) const override;
	
private:
	Cullmode m_Cullmode;
	std::vector<BaseVertex> m_VertexBuffer;
	std::vector<int> m_IndexBuffer;
	std::vector<Elite::FVector3> m_Normals;

	void ParseData(const std::string& objPath);
	void PreCalculateNormals();
};