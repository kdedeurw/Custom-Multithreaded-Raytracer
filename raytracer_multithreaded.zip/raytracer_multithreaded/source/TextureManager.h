#pragma once
#include <map>
#include <string>

class Texture;
class TextureManager
{
public:
	static TextureManager* GetInstance()
	{
		if (!m_pTextureManager)
			m_pTextureManager = new TextureManager{};
		return m_pTextureManager;
	}
	~TextureManager();

	void StoreTexture(const std::string& name, Texture* pTexture);
	void StoreTexture(const std::string& name, const std::string& path);
	Texture* GatherTexture(const std::string& name);

private:
	static TextureManager* m_pTextureManager;
	TextureManager();

	std::map<std::string, Texture*> m_pTextures;
};