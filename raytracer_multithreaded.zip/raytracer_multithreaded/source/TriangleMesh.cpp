#include "pch.h"
#include "TriangleMesh.h"
#include "ObjParser.h"
#include "Ray.h"
#include "HitRecord.h"
#include "Vertex.h"

using namespace Elite;

TriangleMesh::TriangleMesh(const FPoint3& pos, Material* pMaterial, const std::string& objPath)
	: Object{ pos, pMaterial }
	, m_VertexBuffer{}
	, m_IndexBuffer{}
	, m_Normals{}
	, m_Cullmode{ Cullmode::backface }
{
	ParseData(objPath);
	PreCalculateNormals();
}

bool TriangleMesh::Hit(const Ray& ray, HitRecord& hitRecord) const
{
	const size_t size{ m_IndexBuffer.size() };
	int j{};
	for (size_t i{}; i < size; i += 3)
	{
		const FPoint3& v0{ m_VertexBuffer[m_IndexBuffer[i]].position };
		const FPoint3& v1{ m_VertexBuffer[m_IndexBuffer[i + 1]].position };
		const FPoint3& v2{ m_VertexBuffer[m_IndexBuffer[i + 2]].position };
		const FVector3 edgeA{ v1 - v0 };
		const FVector3 edgeB{ v2 - v1 };

		// area is Cross/2

		const FVector3& n{ m_Normals[j] };
		++j; //skip to next (triangle's) normal
		const float dotVN{ Dot(ray.direction, n) };
		if (dotVN == 0)
			continue;

		if (m_Cullmode != Cullmode::noculling)
		{
			//Back-face
			if (dotVN > 0 && m_Cullmode == Cullmode::backface)
				continue;// distibutive property, so dotVN == dotNV
			//Front-face
			else if (dotVN < 0 && m_Cullmode == Cullmode::frontface)
				continue;
		}

		const FPoint3 center{ FPoint3{ (FVector3{v0} +FVector3{v1} +FVector3{v2}) / 3 } };
		const FVector3 L{ center - ray.origin };

		float t{ Dot(L, n) / dotVN };
		if (t < RayData::tMin || t > RayData::tMax)
			continue;
		if (hitRecord.t > t)
			continue;

		const FPoint3 p{ ray.origin + t * ray.direction };

		FVector3 cVec{ p - v0 };
		const float a{ Dot(n, Cross(edgeA, cVec)) };
		if (a < 0)
			continue;

		cVec = { p - v1 };
		const float b{ Dot(n, Cross(edgeB, cVec)) };
		if (b < 0)
			continue;

		const FVector3 edgeC{ v0 - v2 };
		cVec = { p - v2 };
		const float c{ Dot(n, Cross(edgeC, cVec)) };
		if (c < 0)
			continue;

		hitRecord.t = t;
		hitRecord.point = ray.origin + t * ray.direction;
		hitRecord.normal = n;
		hitRecord.pMaterial = m_pMaterial;
		return true;
	}
	return false;
}

void TriangleMesh::ParseData(const std::string& objPath)
{
	ObjParser parser{ objPath };
	parser.ReadFromObjFile();

	m_VertexBuffer = parser.GetVertexBuffer();
	m_IndexBuffer = parser.GetIndexBuffer();
}

void TriangleMesh::PreCalculateNormals()
{
	const size_t size{ m_IndexBuffer.size() };
	for (size_t i{}; i < size; i += 3)
	{
		const FVector3 edgeA{ m_VertexBuffer[m_IndexBuffer[i + 1]].position - m_VertexBuffer[m_IndexBuffer[i]].position };
		const FVector3 edgeB{ m_VertexBuffer[m_IndexBuffer[i + 2]].position - m_VertexBuffer[m_IndexBuffer[i + 1]].position };
		m_Normals.push_back(GetNormalized(Cross(edgeA, edgeB)));
		//normal index buffer is index of vector
	}
}