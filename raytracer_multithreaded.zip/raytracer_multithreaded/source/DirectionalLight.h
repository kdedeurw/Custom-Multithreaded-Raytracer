#pragma once
#include "Light.h"

class DirectionalLight : public Light
{
public:
	DirectionalLight(const Elite::RGBColor& colour, float intensity, const Elite::FVector3& direction);
	~DirectionalLight() = default;

	virtual Elite::RGBColor GetBiradiance(const Elite::FPoint3& pointToShade) override;

	Elite::FVector3 GetDirection(const Elite::FPoint3& pointToShade) const override;

	virtual float GetLambertCosineLaw(const HitRecord& hitRecord) const override;

private:
	Elite::FVector3 m_Direction;
};