#include "pch.h"
#include "Material_Texture_Planar.h"
#include "HitRecord.h"
#include "Plane.h"

using namespace Elite;

Material_Texture_Planar::Material_Texture_Planar(const Elite::RGBColor& diffuseColour, float diffuseReflectance, const char* path)
	: Material_Texture{ diffuseColour, diffuseReflectance, path }
{}

Elite::FVector2 Material_Texture_Planar::GetObjectUV(Object* pObject, const HitRecord& hitRecord) const
{
	const FPoint3 p = FPoint3(hitRecord.point - pObject->GetPosition());
	FVector2 uv{ p.x, -p.z }; //TODO: only for ground plane with worldup normal
	return uv;

	/*
	PlanePrim::PlanePrim(vector3 & a_Normal, float a_D) :
		m_Plane(plane(a_Normal, a_D))
	{
		m_UAxis = vector3(m_Plane.N.y, m_Plane.N.z, -m_Plane.N.x);
		m_VAxis = m_UAxis.Cross(m_Plane.N);
	}

	float u = DOT( a_Pos, m_UAxis ) * m_Material.GetUScale();
	float v = DOT( a_Pos, m_VAxis ) * m_Material.GetVScale();
	*/
}