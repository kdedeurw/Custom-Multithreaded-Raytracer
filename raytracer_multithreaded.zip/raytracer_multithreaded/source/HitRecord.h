#pragma once
#include "EMath.h"
#include "EMathUtilities.h"
#include "ERGBColor.h"

class Material;
struct HitRecord
{
	float t;
	Material* pMaterial;
	Elite::FPoint3 point;
	Elite::FVector3 normal;
};

struct HitRecordColour : public HitRecord
{
	float t;
	Material* pMaterial;
	Elite::FPoint3 point;
	Elite::FVector3 normal;
	Elite::RGBColor color;
};