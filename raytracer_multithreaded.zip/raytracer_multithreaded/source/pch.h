#pragma once
#include "EMath.h"
#include "ERGBColor.h"
