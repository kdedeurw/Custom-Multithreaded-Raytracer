#include "pch.h"
#include "Material_LambertPBR.h"
#include "HitRecord.h"

using namespace Elite;

const RGBColor Material_LambertPBR::m_Dielectric{ 0.04f, 0.04f, 0.04f };

Material_LambertPBR::Material_LambertPBR(const RGBColor& diffuseColour, float reflectance, const RGBColor& albedo, float roughness, bool isMetal)
	: Material_Lambert{ diffuseColour, reflectance }
	, m_Albedo{ albedo }
	, m_Roughness{ roughness }
	, m_IsMetal{ isMetal }
{}

RGBColor Material_LambertPBR::Shade(Object* pObject, const HitRecord& hitRecord, const FVector3& lightDir, const FVector3& viewDir) const
{
	const FVector3 temp{ viewDir + lightDir };
	const FVector3& normal{ hitRecord.normal };
	const FVector3 halfVector = temp / Magnitude(temp);
	//Normalize(halfVector);

	const RGBColor& f0 = (!m_IsMetal) ? m_Dielectric : m_Albedo;

	const BFD bfd = std::move(BFD::CalculateBFD(f0, halfVector, normal, lightDir, viewDir, m_Roughness * m_Roughness));

	const RGBColor kd = (!m_IsMetal) ?  (RGBColor{ 1.f, 1.f, 1.f } - bfd.F) : RGBColor{ 0.f, 0.f, 0.f };
	const RGBColor diffuse = BRDF::Lambert(kd, m_Albedo);

	//RGBColor ks{ RGBColor{ 1.f, 1.f, 1.f } - kd }; // ks = 1 - kd, reflectance <-> refractance == balance between 100%

	const RGBColor cookTorrance = BRDF::CookTorrance(normal, lightDir, viewDir, bfd.B, bfd.F, bfd.D);
	return RGBColor{ kd * diffuse + cookTorrance * bfd.F };
}