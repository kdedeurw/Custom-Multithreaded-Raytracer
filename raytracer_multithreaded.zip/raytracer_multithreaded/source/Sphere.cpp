#include "pch.h"
#include "Sphere.h"
#include "HitRecord.h"
#include "Ray.h"

using namespace Elite;

Sphere::Sphere(const FPoint3& point, float radius, Material* pMaterial)
	: Object{point, pMaterial}
	, m_Radius{radius}
{}

bool Sphere::Hit(const Ray& ray, HitRecord& hitRecord) const
{
	const FVector3 L = m_Position - ray.origin;

	const float tca = Dot(L, ray.direction);

	const float dotL = Dot(L, L);

	const float od2 = dotL - (tca * tca);
	const float rad2 = m_Radius * m_Radius;

	if (od2 > rad2)
		return false;
	// if the od squared is greater than the radius squared, the point will be outside of the sphere/circle

	const float thc2 = rad2 - od2;

	const float thc = sqrtf(thc2);

	const float t = tca - thc;
	if (t < RayData::tMin || t > RayData::tMax)
		return false;

	const float A{ Dot(ray.direction, ray.direction) };
	if (A < 0)
		return false;
	const float B{ tca };
	const float C{ dotL - rad2 };
	const float discriminant{ (B * B) - (A * C) };

	if (discriminant > 0)
	{
		hitRecord.t = t;
		hitRecord.point = ray.origin + hitRecord.t * ray.direction;
		hitRecord.normal = (hitRecord.point - m_Position) / m_Radius;
		//hitRecord.normal = hitRecord.point - m_Position;
		//Elite::Normalize(hitRecord.normal);
		hitRecord.pMaterial = m_pMaterial;
		return true;
	}
	return false;
}

const float Sphere::GetRadius() const
{
	return m_Radius;
}