#include "pch.h"
#include "Material_Texture_Spherical.h"
#include "HitRecord.h"
#include "Sphere.h"

using namespace Elite;

Material_Texture_Spherical::Material_Texture_Spherical(const RGBColor& diffuseColour, float diffuseReflectance, const char* path)
	: Material_Texture{ diffuseColour, diffuseReflectance, path }
{}

Elite::FVector2 Material_Texture_Spherical::GetObjectUV(Object* pObject, const HitRecord& hitRecord) const
{
	FVector2 uv;
	const FPoint3 p = FPoint3(hitRecord.point - pObject->GetPosition());
	const float phi = atan2f(p.z, p.x);
	const float theta = asinf(p.y) / reinterpret_cast<Sphere*>(pObject)->GetRadius();
	uv.x = 1 - (phi + (float)E_PI) / (2.f * (float)E_PI);
	uv.y = (theta + (float)E_PI / 2.f) / (float)E_PI;
	return uv;
}