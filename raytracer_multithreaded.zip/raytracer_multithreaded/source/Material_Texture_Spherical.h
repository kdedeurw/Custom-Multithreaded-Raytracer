#pragma once
#include "Material_Texture.h"

//Documentation used:
//https://viclw17.github.io/2019/04/12/raytracing-uv-mapping-and-texturing/

class Material_Texture_Spherical final : public Material_Texture
{
public:
	Material_Texture_Spherical(const Elite::RGBColor& diffuseColour, float diffuseReflectance, const char* path);
	~Material_Texture_Spherical() = default;

	Elite::FVector2 GetObjectUV(Object* pObject, const HitRecord& hitRecord) const override;
	
private:
};