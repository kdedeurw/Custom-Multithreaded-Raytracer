#include "pch.h"
#include "SceneGraph.h"
#include "Object.h"
#include "Light.h"

SceneGraph::SceneGraph()
	: m_pObjects{}
{}

SceneGraph::~SceneGraph()
{
	for (Object* pObject : m_pObjects)
	{
		delete pObject;
	}
	m_pObjects.clear();

	for (Light* pLight : m_pLights)
	{
		delete pLight;
	}
	m_pLights.clear();
}

void SceneGraph::Update(float deltaTime)
{
	for (Object* pObject : m_pObjects)
	{
		pObject->Update(deltaTime);
	}
}

Object* SceneGraph::AddObject(Object* pObject)
{
	m_pObjects.push_back(pObject);
	return pObject;
}

Light* SceneGraph::AddLight(Light* pLight)
{
	m_pLights.push_back(pLight);
	return m_pLights.back();
}

const std::vector<Object*>& SceneGraph::GetObjects() const
{
	return m_pObjects;
}

const std::vector<Light*>& SceneGraph::GetLights() const
{
	return m_pLights;
}