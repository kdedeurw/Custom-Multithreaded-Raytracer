#pragma once
#include "Ray.h"

struct Ray;
struct HitRecord;
class Material;
class Object
{
public:
	explicit Object(const Elite::FPoint3& pos, Material* pMaterial, float rotSpeed = 0.f);
	virtual ~Object();

	virtual bool Hit(const Ray& ray, HitRecord& hitRecord) const = 0;
	virtual void Update(float deltaTime) {};
	virtual Material* GetMaterial() const;
	const Elite::FPoint3& GetPosition() const;

protected:
	Material* m_pMaterial;
	Elite::FPoint3 m_Position;
};