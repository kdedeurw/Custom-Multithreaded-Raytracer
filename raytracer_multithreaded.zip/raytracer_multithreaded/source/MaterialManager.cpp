#include "pch.h"
#include "MaterialManager.h"

#include "Material.h"
#include "Material_Lambert.h"
#include "Material_LambertPhong.h"
#include "Material_LambertPBR.h"
#include <iostream>

MaterialManager* MaterialManager::m_pMaterialManager{ nullptr };

MaterialManager::MaterialManager()
	: m_pMaterials{}
{}

MaterialManager::~MaterialManager()
{
	std::for_each(m_pMaterials.begin(), m_pMaterials.end(), [](std::pair<std::string, Material*> it) { delete it.second; it.second = nullptr; });
	m_pMaterials.clear();

	m_pMaterialManager = nullptr;
}

Material* MaterialManager::AddMaterial(const std::string& name, Material* pMaterial)
{
	m_pMaterials.insert(std::pair<std::string, Material*>{name, pMaterial});
	return m_pMaterials.begin()->second;
}

Material* MaterialManager::GetMaterial(const std::string& name) const
{
	//std::map<std::string, Material*>::const_iterator it = m_pMaterials.find(name);
	//if (it == m_pMaterials.end())
	//{
	//	std::cout << "\n!Material: " << name << " not found!\n";
	//	return m_pMaterials.at("Lambert");
	//}
	return m_pMaterials.at(name);
}