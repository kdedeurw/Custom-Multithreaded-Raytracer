#include "pch.h"
//External includes
#include "vld.h"
#include "SDL.h"
#include "SDL_surface.h"
//#undef main

//Standard includes
#include <iostream>

//Project includes
#include "EMath.h"
#include "EMathUtilities.h"
#include "ETimer.h"
#include "ERenderer.h"
#include "SceneGraph.h"
#include "Plane.h"
#include "Sphere.h"
#include "ERGBColor.h"
#include "Camera.h"
#include "EventManager.h"
#include "PointLight.h"
#include "DirectionalLight.h"
#include "MaterialManager.h"
#include "Material.h"
#include "Material_Lambert.h"
#include "Material_LambertPhong.h"
#include "Material_LambertPBR.h"
#include "Triangle.h"
#include "TriangleMesh.h"
#include "SceneManager.h"

//Features includes
#include "Material_Texture.h"
#include "Material_Texture_Spherical.h"
#include "Material_Texture_Planar.h"
#include "Material_Reflect.h"

using namespace Elite;

void Init(float width, float height)
{
	//instantiate objects
	SceneManager& sm = *SceneManager::GetInstance();
	MaterialManager& mm = *MaterialManager::GetInstance();
	SceneGraph* pSceneGraph{};

	mm.AddMaterial("LambertRed", new Material_Lambert{ RGBColor{ 1.f, 0.f, 0.f }, 1.f });
	mm.AddMaterial("LambertBlue", new Material_Lambert{ RGBColor{ 0.f, 0.f, 1.f }, 1.f });
	mm.AddMaterial("LambertYellow", new Material_Lambert{ RGBColor{ 1.f, 1.f, 0.f }, 1.f });
	mm.AddMaterial("LambertGreen", new Material_Lambert{ RGBColor{ 0.25f, 0.68f, 0.25f }, 1.f });
	mm.AddMaterial("LambertGrey", new Material_Lambert{ RGBColor{ 0.5f, 0.5f, 0.5f }, 1.f });
	mm.AddMaterial("LambertWhite", new Material_Lambert{ RGBColor{ 1.f, 1.f, 1.f }, 1.f });
	mm.AddMaterial("LambertPhongWhite", new Material_LambertPhong{ RGBColor{1.f, 1.f, 1.f}, 1.f, 1.0f, 60 });
	mm.AddMaterial("LambertPhongYellow", new Material_LambertPhong{ RGBColor{0.69f, 0.68f, 0.25f}, 1.f, 1.0f, 60 });
	mm.AddMaterial("LambertPhongGreen", new Material_LambertPhong{ RGBColor{0.25f, 0.68f, 0.25f}, 1.f, 1.0f, 60 });
	mm.AddMaterial("LambertPhongGrey", new Material_LambertPhong{ RGBColor{0.5f, 0.5f, 0.5f}, 1.f, 1.0f, 60 });
	mm.AddMaterial("PBRMetallic1.0", new Material_LambertPBR{ RGBColor{ 0.f, 0.f, 1.f }, 1.f, RGBColor{ 0.95f, 0.93f, 0.88f }, 1.f, true });
	mm.AddMaterial("PBRMetallic0.6", new Material_LambertPBR{ RGBColor{ 0.f, 0.f, 1.f }, 1.f, RGBColor{ 0.95f, 0.93f, 0.88f }, 0.6f, true });
	mm.AddMaterial("PBRMetallic0.1", new Material_LambertPBR{ RGBColor{ 0.f, 0.f, 1.f }, 1.f, RGBColor{ 0.95f, 0.93f, 0.88f }, 0.1f, true });
	mm.AddMaterial("PBRDielectric1.0", new Material_LambertPBR{ RGBColor{ 0.f, 0.f, 1.f }, 1.f, RGBColor{ 0.95f, 0.93f, 0.88f }, 1.f, false });
	mm.AddMaterial("PBRDielectric0.6", new Material_LambertPBR{ RGBColor{ 0.f, 0.f, 1.f }, 1.f, RGBColor{ 0.95f, 0.93f, 0.88f }, 0.6f, false });
	mm.AddMaterial("PBRDielectric0.1", new Material_LambertPBR{ RGBColor{ 0.f, 0.f, 1.f }, 1.f, RGBColor{ 0.95f, 0.93f, 0.88f }, 0.1f, false });

	//Scene 0 (Material Test Scene)
	pSceneGraph = new SceneGraph{};
	pSceneGraph->AddObject(new Sphere{ FPoint3{ -1.f, 1.f, 0.f }, 1.f, mm.GetMaterial("LambertPhongYellow") });
	pSceneGraph->AddObject(new Sphere{ FPoint3{ 1.f, 1.f, 0.f }, 1.f, mm.GetMaterial("LambertGreen") });
	pSceneGraph->AddObject(new Plane{ FPoint3{ 0.f, 0.f, 0.f}, FVector3{ 0.f, 1.f, 0.f }, mm.GetMaterial("LambertYellow") });
	//pSceneGraph->AddObject(new Plane{ FPoint3{ 0.f, 0.f, -10.f}, FVector3{ 0.f, 0.f, 1.f }, mm.GetMaterial("LambertYellow") });
	pSceneGraph->AddLight(new PointLight{ RGBColor{1.f, 1.f, 1.f}, 25.f, FPoint3{0.f, 5.f, -5.f} });
	pSceneGraph->AddLight(new PointLight{ RGBColor{1.f, 1.f, 1.f}, 25.f, FPoint3{0.f, 2.5f, 5.f} });
	pSceneGraph->AddLight(new DirectionalLight{ RGBColor{1.f, 1.f, 1.f}, 1.f, FVector3{0.f, -1.f, 0.f} });
	sm.AddSceneGraph(pSceneGraph);

	//Final Scene 1 (6 spheres and 3 triangles)
	pSceneGraph = new SceneGraph{};
	pSceneGraph->AddObject(new Sphere{ FPoint3{ -2.5f, 1.f, 0.f }, 1.f, mm.GetMaterial("PBRMetallic1.0") });
	pSceneGraph->AddObject(new Sphere{ FPoint3{ 0.f, 1.f, 0.f }, 1.f, mm.GetMaterial("PBRMetallic0.6") });
	pSceneGraph->AddObject(new Sphere{ FPoint3{ 2.5f, 1.f, 0.f }, 1.f, mm.GetMaterial("PBRMetallic0.1") });
	pSceneGraph->AddObject(new Sphere{ FPoint3{ -2.5f, 3.5f, 0.f }, 1.f, mm.GetMaterial("PBRDielectric1.0") });
	pSceneGraph->AddObject(new Sphere{ FPoint3{ 0.f, 3.5f, 0.f }, 1.f, mm.GetMaterial("PBRDielectric0.6") }); //TODO: fix this material not showing correctly
	pSceneGraph->AddObject(new Sphere{ FPoint3{ 2.5f, 3.5f, 0.f }, 1.f, mm.GetMaterial("PBRDielectric0.1") });
	
	//pSceneGraph->AddObject(new Plane{ FPoint3{ 0.f, 0.f, 0.f}, FVector3{ 0.f, 1.f, 0.f }, mm.GetMaterial("LambertPhongGrey") });
	pSceneGraph->AddObject(new Plane{ FPoint3{ 0.f, 0.f, -10.f}, FVector3{ 0.f, 0.f, 1.f }, mm.GetMaterial("LambertPhongGreen") });
	//pSceneGraph->AddObject(new Plane{ FPoint3{ 10.f, 0.f, 0.f}, FVector3{ -1.f, 0.f, 0.f }, mm.GetMaterial("LambertPhongYellow") });
	//pSceneGraph->AddObject(new Plane{ FPoint3{ -10.f, 0.f, 0.f}, FVector3{ 1.f, 0.f, 0.f }, mm.GetMaterial("LambertPhongYellow") });

	pSceneGraph->AddObject(new Triangle{ FPoint3{ -2.5f, 5.5f, 0.f}, mm.GetMaterial("LambertPhongYellow"), FPoint3{ -0.75f, 1.5f, 0.f }, FPoint3{ -0.75f, 0.f, 0.f }, FPoint3{ 0.75f, 0.f, 0.f }, Triangle::Cullmode::noculling, 1.f });
	pSceneGraph->AddObject(new Triangle{ FPoint3{ 0.f, 5.5f, 0.f}, mm.GetMaterial("LambertRed"), FPoint3{ -0.75f, 1.5f, 0.f }, FPoint3{ -0.75f, 0.f, 0.f }, FPoint3{ 0.75f, 0.f, 0.f }, Triangle::Cullmode::frontface, 1.f });
	pSceneGraph->AddObject(new Triangle{ FPoint3{ 2.5f, 5.5f, 0.f}, mm.GetMaterial("LambertBlue"), FPoint3{ -0.75f, 1.5f, 0.f }, FPoint3{ -0.75f, 0.f, 0.f }, FPoint3{ 0.75f, 0.f, 0.f }, Triangle::Cullmode::backface, 1.f });

	pSceneGraph->AddLight(new PointLight{ RGBColor{1.f, 1.f, 1.f}, 25.f, FPoint3{0.f, 5.f, -5.f} });
	pSceneGraph->AddLight(new PointLight{ RGBColor{1.f, 1.f, 1.f}, 25.f, FPoint3{0.f, 5.f, 5.f} });
	pSceneGraph->AddLight(new PointLight{ RGBColor{1.f, 1.f, 1.f}, 10.f, FPoint3{-5.f, 5.f, 2.5f} });
	//pSceneGraph->AddLight(new DirectionalLight{ RGBColor{1.f, 1.f, 1.f}, 1.f, FVector3{0.f, -1.f, 0.f} });
	pSceneGraph->AddLight(new DirectionalLight{ RGBColor{1.f, 1.f, 1.f}, 1.f, FVector3{0.f, -0.707f, -0.707f} });
	sm.AddSceneGraph(pSceneGraph);

	//Scene 2 (triangle mesh)
	pSceneGraph = new SceneGraph{};
	pSceneGraph->AddObject(new Plane{ FPoint3{ 0.f, 0.f, 0.f}, FVector3{ 0.f, 1.f, 0.f }, mm.GetMaterial("LambertGreen") });
	pSceneGraph->AddObject(new TriangleMesh{ FPoint3{}, mm.GetMaterial("LambertWhite"), "Resources/lowpoly_bunny.obj" });
	pSceneGraph->AddLight(new PointLight{ RGBColor{1.f, 1.f, 1.f}, 25.f, FPoint3{0.f, 5.f, 5.f} });
	pSceneGraph->AddLight(new DirectionalLight{ RGBColor{1.f, 1.f, 1.f}, 1.f, FVector3{0.f, -0.707f, -0.707f} });
	sm.AddSceneGraph(pSceneGraph);

	//Scene 3 sphere with texture mapping
	mm.AddMaterial("EarthTexture", new Material_Texture_Spherical{ RGBColor{ 1.f, 1.f, 1.f }, 1.f, "Resources/2k_earth_daymap.jpg" });
	mm.AddMaterial("MoonTexture", new Material_Texture_Spherical{ RGBColor{ 1.f, 1.f, 1.f }, 1.f, "Resources/moondiffuse.jpg" });
	mm.AddMaterial("CheckerTexture", new Material_Texture_Planar{ RGBColor{ 1.f, 1.f, 1.f }, 1.f, "Resources/1K_UV_checker.jpg" });
	mm.AddMaterial("ReflectMaterial", new Material_Reflect{ {1.f, 1.f, 1.f}, 1.f });

	pSceneGraph = new SceneGraph{};
	pSceneGraph->AddLight(new PointLight{ RGBColor{1.f, 1.f, 1.f}, 25.f, FPoint3{0.f, 5.f, 5.f} });
	pSceneGraph->AddLight(new DirectionalLight{ RGBColor{1.f, 1.f, 1.f}, 2.f, FVector3{0.f, -0.707f, -0.707f} });
	//pSceneGraph->AddLight(new DirectionalLight{ RGBColor{1.f, 1.f, 1.f}, 2.f, FVector3{0.f, 0.707f, 0.707f} });
	pSceneGraph->AddLight(new PointLight{ RGBColor{1.f, 1.f, 1.f}, 25.f, FPoint3{0.f, -5.f, -5.f} });

	pSceneGraph->AddObject(new Sphere{ FPoint3{}, 1.f, mm.GetMaterial("EarthTexture") });
	pSceneGraph->AddObject(new Sphere{ FPoint3{ 5.f, 1.f, -1.f }, 1.f, mm.GetMaterial("MoonTexture") });
	pSceneGraph->AddObject(new Plane{ FPoint3{ 0.f, -10.f, 0.f }, FVector3{0.f, 1.f, 0.f}, mm.GetMaterial("CheckerTexture") });
	pSceneGraph->AddObject(new Sphere{ FPoint3{0.f, -5.f, 0.f}, 2.f, mm.GetMaterial("ReflectMaterial") });
	pSceneGraph->AddObject(new Sphere{ FPoint3{ -5.f, -1.f, 2.f }, 1.f, mm.GetMaterial("LambertPhongYellow") });
	sm.AddSceneGraph(pSceneGraph);
}

void ShutDown(SDL_Window* pWindow)
{
	SDL_DestroyWindow(pWindow);
	SDL_Quit();
}

int main(int argc, char* args[])
{
	//Unreferenced parameters
	(void)argc;
	(void)args;

	//Create window + surfaces
	SDL_Init(SDL_INIT_VIDEO);

	const uint32_t width = 640;
	const uint32_t height = 480;
	SDL_Window* pWindow = SDL_CreateWindow(
		"Custom RayTracer Multithreaded - Dedeurwaerder Kristof",
		SDL_WINDOWPOS_UNDEFINED,
		SDL_WINDOWPOS_UNDEFINED,
		width, height, 0);

	if (!pWindow)
		return 1;

	//Initialize framework
	Camera* pCamera = new Camera{ FPoint3{ 0.f, 3.5f, 10.f }, 45.f };
	pCamera->SetAspectRatio((float)width, (float)height);
	Elite::Timer* pTimer = new Elite::Timer();
	Elite::Renderer* pRenderer = new Elite::Renderer(pWindow, pCamera); //(RHS)
	SceneManager* pSceneManager = SceneManager::GetInstance();
	EventManager* pEventManager = EventManager::GetInstance();

	EventManager::GetInstance();//instantiate object

	Init((float)width, (float)height);

	pRenderer->StartThreads();

	//Start loop
	pTimer->Start();
	float printTimer = 0.f;
	bool isLooping = true;
	bool takeScreenshot = false;
	while (isLooping)
	{
		const float deltaTime = pTimer->GetElapsed();

		//--------- Get input events ---------
		isLooping = pEventManager->ProcessInputs(deltaTime, takeScreenshot);

		//--------- CameraMovement ---------
		bool lmb, rmb, m3;
		pEventManager->GetMouseButtonsClicked(lmb, rmb, m3);
		pCamera->ProcessInputs(deltaTime, lmb, rmb, m3);
		int scrollwheel = pEventManager->GetScrollWheelValue();
		if (scrollwheel != 0)
			pCamera->ChangeSpeed((float)scrollwheel);

		//--------- Render ---------
		pRenderer->RenderMultithreaded();

		//--------- Timer ---------
		pTimer->Update();
		printTimer += deltaTime;
		if (printTimer >= 1.f)
		{
			printTimer = 0.f;
			std::cout << "FPS: " << pTimer->GetFPS() << std::endl;
		}

		//--------- Update Objects ---------
		pSceneManager->Update(deltaTime);

		//Save screenshot after full render
		if (takeScreenshot)
		{
			if (!pRenderer->SaveBackbufferToImage())
				std::cout << "Screenshot saved!" << std::endl;
			else
				std::cout << "Something went wrong. Screenshot not saved!" << std::endl;
			takeScreenshot = false;
		}
	}
	//Shutdown framework
	pTimer->Stop();
	pRenderer->StopThreads();

	delete pRenderer;
	delete pTimer;
	delete pCamera;

	delete EventManager::GetInstance();
	delete MaterialManager::GetInstance();
	delete SceneManager::GetInstance();

	ShutDown(pWindow);
	return 0;
}