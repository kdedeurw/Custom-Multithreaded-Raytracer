#pragma once
#include "Material_Lambert.h"

class Material_LambertPhong : public Material_Lambert
{
public:
	Material_LambertPhong(const Elite::RGBColor& diffuseColour, float diffuseReflectance, float specularReflectance, float phongExponent);
	~Material_LambertPhong() = default;

	virtual Elite::RGBColor Shade(Object* pObject, const HitRecord& hitRecord, const Elite::FVector3& lightDir, const Elite::FVector3& viewDir) const override;

private:
	float m_PhongExponent;
	float m_SpecularReflectance;
};