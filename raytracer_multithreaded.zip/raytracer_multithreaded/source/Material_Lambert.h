#pragma once
#include "Material.h"

class Material_Lambert : public Material
{
public:
	Material_Lambert(const Elite::RGBColor& diffuseColour, float reflectance);
	virtual ~Material_Lambert() = default;

	virtual Elite::RGBColor Shade(Object* pObject, const HitRecord& hitRecord, const Elite::FVector3& w0, const Elite::FVector3& w1) const override;
};