#pragma once
#include <map>
#include <string>
#include <algorithm>

class Material;

class MaterialManager
{
public:
	static MaterialManager* GetInstance()
	{
		if (!m_pMaterialManager) m_pMaterialManager = new MaterialManager{};
		return m_pMaterialManager;
	}
	~MaterialManager();

	Material* AddMaterial(const std::string& name, Material* pMaterial);
	Material* GetMaterial(const std::string& name) const;

private:
	MaterialManager();
	static MaterialManager* m_pMaterialManager;
	std::map<std::string, Material*> m_pMaterials;
};