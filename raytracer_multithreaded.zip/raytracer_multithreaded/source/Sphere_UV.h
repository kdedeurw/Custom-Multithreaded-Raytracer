#pragma once
#include "Sphere.h"

class Sphere_UV : public Sphere
{
	explicit Sphere_UV(const FPoint3& point, float radius, Material* pMaterial, Texture* pTexture);
	~Sphere_UV() = default;

	virtual bool HitUV(const Ray& ray, HitRecordTex& hitRecordTex) const;
};