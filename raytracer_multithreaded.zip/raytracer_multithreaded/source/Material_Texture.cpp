#include "pch.h"
#include "Material_Texture.h"
#include <SDL_image.h>
#include <SDL_surface.h>
#include <iostream>
#include "HitRecord.h"

using namespace Elite;

Material_Texture::Material_Texture(const RGBColor& diffuseColour, float diffuseReflectance, const char* path)
	: Material{ diffuseColour, diffuseReflectance }
	, m_pSurface{ IMG_Load(path) }
{
	if (!m_pSurface)
		std::cout << "\n!Texture not loaded correctly!\n";
}

Material_Texture::~Material_Texture()
{
	if (m_pSurface)
		SDL_FreeSurface(m_pSurface);
	m_pSurface = nullptr;
}

Elite::RGBColor Material_Texture::Shade(Object* pObject, const HitRecord& hitRecord, const Elite::FVector3& lightDir, const Elite::FVector3& viewDir) const
{
	return BRDF::Lambert(m_DiffuseReflectance, m_DiffuseColour) + Sample(GetObjectUV(pObject, hitRecord));
}

RGBColor Material_Texture::Sample(const FVector2& uv) const
{
	Uint8 r, g, b;

	uint32_t x = uint32_t(uv.x * m_pSurface->w);
	uint32_t y = uint32_t((1 - uv.y) * m_pSurface->h - 0.001f);

	if (x < 0) x = 0;
	if (y < 0) y = 0;

	if (x > (uint32_t)m_pSurface->w - 1)
		x = (uint32_t)m_pSurface->w - 1;

	if (y > (uint32_t)m_pSurface->h - 1)
		y = (uint32_t)m_pSurface->h - 1;

	const Uint8* pixels = (Uint8*)m_pSurface->pixels;
	const uint32_t pixel = uint32_t(3 * x + 3 * m_pSurface->w * y);
	r = Uint8(pixels[pixel]);
	g = Uint8(pixels[pixel + 1]);
	b = Uint8(pixels[pixel + 2]);

	return RGBColor{ r / 255.f, g / 255.f, b / 255.f };
}