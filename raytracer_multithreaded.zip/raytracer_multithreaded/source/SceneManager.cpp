#include "pch.h"
#include "SceneManager.h"
#include "SceneGraph.h"

SceneManager* SceneManager::m_pSceneManager{};

SceneManager::SceneManager()
	: m_pSceneGraphs{}
	, m_SceneIndex{}
	, m_EnableDirectionalLights{ true }
	, m_EnableHardShadows{ true }
	, m_EnablePointLights{ true }
	, m_Toggle{ Toggle::Combined }
{}

SceneManager::~SceneManager()
{
	for (SceneGraph* pSceneGraph : m_pSceneGraphs)
	{
		delete pSceneGraph;
	}
	m_pSceneGraphs.clear();
}

SceneGraph* SceneManager::AddSceneGraph(SceneGraph* pSceneGraph)
{
	if (std::find(m_pSceneGraphs.begin(), m_pSceneGraphs.end(), pSceneGraph) == m_pSceneGraphs.end())
		m_pSceneGraphs.push_back(pSceneGraph);
	return m_pSceneGraphs.back();
}

const SceneGraph* SceneManager::GetSceneGraph() const
{
	return m_pSceneGraphs[m_SceneIndex];
}

void SceneManager::Update(float deltaTime)
{
	m_pSceneGraphs[m_SceneIndex]->Update(deltaTime);
}

void SceneManager::SwapSceneGraph()
{
	++m_SceneIndex;
	if (m_SceneIndex >= (int)m_pSceneGraphs.size())
		m_SceneIndex = 0;
}

void SceneManager::ToggleDirectionalLights()
{
	m_EnableDirectionalLights = !m_EnableDirectionalLights;
}

void SceneManager::TogglePointLights()
{
	m_EnablePointLights = !m_EnablePointLights;
}

void SceneManager::ToggleHardShadows()
{
	m_EnableHardShadows = !m_EnableHardShadows;
}

void SceneManager::ToggleThatThing()
{
	m_Toggle = Toggle((int)m_Toggle + 1);
	if ((int)m_Toggle > 2)
		m_Toggle = Toggle::Combined;
}