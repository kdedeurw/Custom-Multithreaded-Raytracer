#pragma once
#include "Object.h"

class Plane : public Object
{
public:
	explicit Plane(const Elite::FPoint3& point, const Elite::FVector3& normal, Material* pMaterial);
	~Plane() = default;

	virtual bool Hit(const Ray& ray, HitRecord& hitRecord) const override;
	const Elite::FVector3& GetNormal() const;

private:
	Elite::FVector3 m_Normal;
};