#include "pch.h"
//External includes
#include "SDL.h"
#include "SDL_surface.h"

//Project includes
#include "ERenderer.h"

#include "Camera.h"
#include "HitRecord.h"
#include "Ray.h"

#include "SceneManager.h"
#include "SceneGraph.h"
#include "MaterialManager.h"

#include "Object.h"
#include "Light.h"
#include "Material.h"

#include <typeinfo>
#include "PointLight.h"
#include "DirectionalLight.h"

#include <thread>
#include <future>
#include <iostream>

//Feature includes
#include "Material_Texture.h"

Elite::Renderer::Renderer(SDL_Window* pWindow, Camera* pCamera)
	: m_pWindow{ pWindow }
	, m_IsRendering{}
	, m_pFrontBuffer{ SDL_GetWindowSurface(pWindow) }
	, m_pBackBuffer{}
	, m_pBackBufferPixels{}
	, m_Width{}
	, m_Height{}
	, m_pCamera{ pCamera }
	, m_pThreads{}
{
	//Initialize
	int width{ -1 }, height{ -1 };
	SDL_GetWindowSize(pWindow, &width, &height);
	m_Width = static_cast<unsigned int>(width);
	m_Height = static_cast<unsigned int>(height);
	m_pBackBuffer = SDL_CreateRGBSurface(0, m_Width, m_Height, 32, 0, 0, 0, 0);
	m_pBackBufferPixels = (unsigned int*)m_pBackBuffer->pixels;
	//Fun fact: this surface doesn't need to be locked, 
	//as it makes sense because we're only reading it during buffer swapping
	//reading and writing can be done at any time
	//bool mustLock = SDL_MUSTLOCK(m_pBackBuffer);
}

Elite::Renderer::~Renderer()
{
	m_pCamera = nullptr;

	if (m_pThreads)
		delete[] m_pThreads;
	m_pThreads = nullptr;
}

void Elite::Renderer::Render()
{
	SDL_LockSurface(m_pBackBuffer);
	const SceneManager* pSceneManager{ SceneManager::GetInstance() };
	const SceneGraph* pSceneGraph{ pSceneManager->GetSceneGraph() };

	//Loop over all the pixels
	for (uint32_t r = 0; r < m_Height; ++r)
	{
		for (uint32_t c = 0; c < m_Width; ++c)
		{
			const Ray ray{ GetCorrRay(float(c),float(r)) };

			HitRecord closestHit{};
			closestHit.t = RayData::tMax;
			// loop through all objects in scene
			HitRecord currHit{};
			Object* pCurrObject{};
			for (Object* pObject : pSceneGraph->GetObjects())
			{
				if (pObject->Hit(ray, currHit))
				{
					if (closestHit.t > currHit.t)
					{
						closestHit = currHit;
						pCurrObject = pObject;
					}
					currHit.t = 0.f; //trianglemesh bug, it will not render if any object is present infront or behind it
				}
			}

			// light calculations
			RGBColor finalColourPixel{};
			//for each pixel hit by our ray
			if (closestHit.t < RayData::tMax && closestHit.t > RayData::tMin)//gets rid of nullptr material issues
			{
				for (Light* pLight : pSceneGraph->GetLights())
				{
					if (typeid(*pLight) == typeid(PointLight) && !pSceneManager->IsPointLights())
						continue;
					if (typeid(*pLight) == typeid(DirectionalLight) && !pSceneManager->IsDirLights())
						continue;

					const float cosineLaw{ pLight->GetLambertCosineLaw(closestHit) };
					if (cosineLaw < 0.f)
						continue;

					// hard shadowing
					if (pSceneManager->IsHardShadows())
					{
						bool isVisible{ true };
						const Ray toLight{ closestHit.point, pLight->GetDirection(closestHit.point) };
						for (Object* pObject : pSceneGraph->GetObjects())
						{
							HitRecord hitRecord{};
							if (pObject->Hit(toLight, hitRecord))
							{
								//goto ColourCalculation; //final usage of goto: breaking out of nested for loops
								isVisible = false;
								break; // if light is already not visible, stop checking
							}
						}
						if (!isVisible)
							continue; // skip light calculations

						//TODO: fix hard shadowing bug
					}
					//if (!closestHit.pMaterial)
					//	continue;

				//ColourCalculation:
					const SceneManager::Toggle toggle{ pSceneManager->ThatThing() };
					if (toggle == SceneManager::Toggle::Irradiance)
					{
						const RGBColor biradiance{ pLight->GetBiradiance(closestHit.point) };
						finalColourPixel += biradiance * cosineLaw;
					}
					else if (toggle == SceneManager::Toggle::BRDF)
					{
						const RGBColor BRDF{ closestHit.pMaterial->Shade(pCurrObject, closestHit, pLight->GetDirection(closestHit.point), GetNormalized(-ray.direction)) };
						finalColourPixel +=  BRDF * cosineLaw;
					}
					else //combined
					{
						const RGBColor biradiance{ pLight->GetBiradiance(closestHit.point) };
						const RGBColor BRDF{ closestHit.pMaterial->Shade(pCurrObject, closestHit, pLight->GetDirection(closestHit.point), GetNormalized(-ray.direction)) };
						finalColourPixel += biradiance * BRDF * cosineLaw;
					}
					//switch statement secretly does an extra operation instead of just 'if-else'
					//it checks whether the amount of checks are above 10, in this case there's 3, so no need for it
				}
				finalColourPixel.MaxToOne();
			}
			// final draw
			m_pBackBufferPixels[c + (r * m_Width)] = SDL_MapRGB(m_pBackBuffer->format,
				static_cast<uint8_t>(finalColourPixel.r * 255.f),
				static_cast<uint8_t>(finalColourPixel.g * 255.f),
				static_cast<uint8_t>(finalColourPixel.b * 255.f));
		}
	}

	SDL_UnlockSurface(m_pBackBuffer);
	SDL_BlitSurface(m_pBackBuffer, 0, m_pFrontBuffer, 0);
	SDL_UpdateWindowSurface(m_pWindow);
}

bool Elite::Renderer::SaveBackbufferToImage() const
{
	return SDL_SaveBMP(m_pBackBuffer, "BackbufferRender.bmp");
}

Ray Elite::Renderer::GetCorrRay(float c, float r) const
{
	const float fov{ m_pCamera->GetFov() };
	const float x{ (2 * ((c + 0.5f) / m_Width) - 1) * m_pCamera->GetAspectRatio() * fov };
	const float y{ (1 - 2 * ((r + 0.5f) / m_Height)) * fov };
	FVector3 direction{ FPoint3{x, y, -1} };
	m_pCamera->Rotate(direction);
	Normalize(direction);
	return Ray{ m_pCamera->GetPos(), direction };
}

void Elite::Renderer::RenderMultithreaded()
{
	//SDL_LockSurface(m_pBackBuffer);

	std::unique_lock<std::mutex> lock{ m_Mutex };
	m_ConditionVariable.wait(lock, [this]() { return m_ThreadsFinished == m_ThreadAmount; }); //lock thread until all renderthreads are done
	m_ThreadsFinished = 0;
	
	//SDL_UnlockSurface(m_pBackBuffer);
	SDL_BlitSurface(m_pBackBuffer, 0, m_pFrontBuffer, 0);
	SDL_UpdateWindowSurface(m_pWindow);

	m_ConditionVariable.notify_all(); //wake up all threads for rendering next frame
}

void Elite::Renderer::StartThreads()
{
	m_IsRendering = true;
	m_pThreads = new std::thread[m_ThreadAmount];

	const uint w2 = m_Width / m_ThreadAmount;
	const uint h2 = m_Height;
	for (int i{}; i < m_ThreadAmount; ++i)
	{
		//threads are now equally being divided in columns
		m_pThreads[i] = std::thread(&Elite::Renderer::RenderPartOfScreen, this, i, i * w2, 0, w2, h2);
	}

}

void Elite::Renderer::StopThreads()
{
	m_IsRendering = false;
	m_ConditionVariable.notify_all(); //wake up all threads for exit
	for (int i{}; i < m_ThreadAmount; ++i)
	{
		m_pThreads[i].join();
	}
}

void Elite::Renderer::RenderPartOfScreen(uint threadId, uint x, uint y, uint w, uint h)
{
	SceneManager* pSceneManager{ SceneManager::GetInstance() };

	while (m_IsRendering)
	{
		const SceneGraph* pSceneGraph{ pSceneManager->GetSceneGraph() };
		//thread shouldn't render twice per frame

		//Loop over all the pixels
		for (uint r = y; r < y + h; ++r)
		{
			for (uint c = x; c < x + w; ++c)
			{
				const Ray ray{ GetCorrRay(float(c),float(r)) };

				HitRecord closestHit{};
				closestHit.t = RayData::tMax;
				// loop through all objects in scene
				HitRecord currHit{};
				Object* pCurrObject{};
				for (Object* pObject : pSceneGraph->GetObjects())
				{
					if (pObject->Hit(ray, currHit))
					{
						if (closestHit.t > currHit.t)
						{
							closestHit = currHit;
							pCurrObject = pObject;
						}
						currHit.t = 0.f; //trianglemesh bug, it will not render if any object is present infront or behind it
					}
				}

				// light calculations
				RGBColor finalColourPixel{};
				//for each pixel hit by our ray
				if (closestHit.t < RayData::tMax && closestHit.t > RayData::tMin)//gets rid of nullptr material issues
				{
					for (Light* pLight : pSceneGraph->GetLights())
					{
						if (typeid(*pLight) == typeid(PointLight) && !pSceneManager->IsPointLights())
							continue;
						if (typeid(*pLight) == typeid(DirectionalLight) && !pSceneManager->IsDirLights())
							continue;

						const float cosineLaw{ pLight->GetLambertCosineLaw(closestHit) };
						if (cosineLaw < 0.f)
							continue;

						// hard shadowing
						if (pSceneManager->IsHardShadows())
						{
							bool isVisible{ true };
							const Ray toLight{ closestHit.point, pLight->GetDirection(closestHit.point) };
							for (Object* pObject : pSceneGraph->GetObjects())
							{
								HitRecord hitRecord{};
								if (pObject->Hit(toLight, hitRecord))
								{
									//goto ColourCalculation; //final usage of goto: breaking out of nested for loops
									isVisible = false;
									break; // if light is already not visible, stop checking
								}
							}
							if (!isVisible)
								continue; // skip light calculations
						
							//TODO: fix hard shadowing bug
						}
						//if (!closestHit.pMaterial)
						//	continue;

						const SceneManager::Toggle toggle{ pSceneManager->ThatThing() };
						if (toggle == SceneManager::Toggle::Irradiance)
						{
							const RGBColor biradiance{ pLight->GetBiradiance(closestHit.point) };
							finalColourPixel += biradiance * cosineLaw;
						}
						else if (toggle == SceneManager::Toggle::BRDF)
						{
							const RGBColor BRDF{ closestHit.pMaterial->Shade(pCurrObject, closestHit, pLight->GetDirection(closestHit.point), GetNormalized(-ray.direction)) };
							finalColourPixel += BRDF * cosineLaw;
						}
						else //combined
						{
							const RGBColor biradiance{ pLight->GetBiradiance(closestHit.point) };
							const RGBColor BRDF{ closestHit.pMaterial->Shade(pCurrObject, closestHit, pLight->GetDirection(closestHit.point), GetNormalized(-ray.direction)) };
							finalColourPixel += biradiance * BRDF * cosineLaw;
						}
					}
					finalColourPixel.MaxToOne();
				}

				const uint pixelIdx = c + (r * m_Width);
				m_pBackBufferPixels[pixelIdx] = SDL_MapRGB(m_pBackBuffer->format,
					static_cast<uint8_t>(finalColourPixel.r * 255.f),
					static_cast<uint8_t>(finalColourPixel.g * 255.f),
					static_cast<uint8_t>(finalColourPixel.b * 255.f));
			}
		}
		++m_ThreadsFinished;
		m_ConditionVariable.notify_all(); //notify main thread as well
		std::unique_lock<std::mutex> lock{ m_Mutex };
		m_ConditionVariable.wait(lock, [this]() { return !m_ThreadsFinished || !m_IsRendering; }); //pause thread unless exit | wake up IF new frame
	}
}