#include "pch.h"
#include "Material_Lambert.h"

using namespace Elite;

Material_Lambert::Material_Lambert(const RGBColor& diffuseColour, float reflectance)
	: Material{diffuseColour, reflectance}
{}

RGBColor Material_Lambert::Shade(Object* pObject, const HitRecord& hitRecord, const FVector3& lightDir, const FVector3& viewDir) const
{
	return BRDF::Lambert(m_DiffuseReflectance, m_DiffuseColour);
}