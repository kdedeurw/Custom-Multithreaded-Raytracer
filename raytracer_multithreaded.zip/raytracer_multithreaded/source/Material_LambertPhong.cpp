#include "pch.h"
#include "Material_LambertPhong.h"
#include "HitRecord.h"

using namespace Elite;

Material_LambertPhong::Material_LambertPhong(const RGBColor& diffuseColour, float diffuseReflectance, float specularReflectance, float phongExponent)
	: Material_Lambert{ diffuseColour, diffuseReflectance }
	, m_SpecularReflectance{ specularReflectance }
	, m_PhongExponent{ phongExponent }
{}

RGBColor Material_LambertPhong::Shade(Object* pObject, const HitRecord& hitRecord, const FVector3& lightDir, const FVector3& viewDir) const
{
	return BRDF::Lambert(RGBColor{ m_DiffuseReflectance, m_DiffuseReflectance, m_DiffuseReflectance }, m_DiffuseColour)
		+ BRDF::Phong(m_SpecularReflectance, m_PhongExponent, hitRecord.normal, lightDir, viewDir);
}