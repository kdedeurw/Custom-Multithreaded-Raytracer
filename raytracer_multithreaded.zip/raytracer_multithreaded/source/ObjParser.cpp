#include "pch.h"
#include "ObjParser.h"
#include <iostream>
#include <sstream>
#include "Vertex.h"

using namespace Elite;

ObjParser::ObjParser()
	: ObjParser{ "" }
{}

ObjParser::ObjParser(const std::string& filePath)
	: m_ReadFile{}
	, m_Vertices{}
	, m_Positions{}
	, m_PositionIndices{}
	, m_IndexBuffer{}
	, m_UVIndices{}
	, m_NormalIndices{}
{
	OpenFile(filePath);
}

ObjParser::~ObjParser()
{
	m_Vertices.clear();
	CloseFile();
}

void ObjParser::ReadFromObjFile()
{
	if (m_ReadFile.is_open())
	{
		std::string line{};
		size_t lineCount{};
		while (std::getline(m_ReadFile, line))
		{
			++lineCount;
			if (line.empty() || line.front() == '#')
				continue; // skip empty and comment lines
			std::string prefix{};
			std::getline(std::stringstream{ line }, prefix, ' '); // prefix always in front, delimited by space(s)
			if (prefix == "v")
			{
				std::stringstream position{ line.substr(3) }; // create substring without 'v  ' (v and 2 spaces)
				StorePosition(position);
			}
			else if (prefix == "f") // every line starting with 'f'
			{
				std::stringstream face{ line.substr(2) }; // create substring without 'f ' (f and 1 space)
				StoreFace(face);
			}
			else if (prefix == "vt")
			{
				std::stringstream uv{ line.substr(3) }; // create substring without 'vt ' (vt and 1 space)
				StoreUV(uv);
			}
			else if (prefix == "vn")
			{
				std::stringstream normal{ line.substr(3) }; // create substring without 'vn ' (vn and 1 space)
				StoreNormal(normal);
			}
			else
			{
				std::cout << "\n!Unknown prefix found at line: " << lineCount << ", prefix: \' " << prefix << " \'!\n";
				std::cout << "Full line: \' " << line << " \'\n";
			}
		}

		// sort all possible faces, which idx's are now listed in vector<int>'s, and link them with the values of the normals and uvs we collected
		//AssignUVs(); // create std::vector<FVector3> filled with UV coords (no need to store these separately)
		//AssignNormals(); // create std::vector<FVector3> filled with normals (no need to store these separately)

		std::cout << "\n!Done parsing, creating vertices based on parsed info now!\n";

		AssignVertices(); // create vertices, filled with positions, normals, UV coords (and colours?) all at once (store them all in vertex)

		std::cout << "\n!All done!\n";
	}
	else std::cout << "\n!Unable to open file!\n";
}

void ObjParser::ReadFromObjFile(const std::string& filePath)
{
	if (m_ReadFile.is_open())
	{
		CloseFile();
		OpenFile(filePath);
	}
	else
		OpenFile(filePath);
	
	ReadFromObjFile();
}

void ObjParser::StorePosition(std::stringstream& position)
{
	std::string x{}, y{}, z{};
	GetFirstSecondThird(position, x, y, z);
	m_Positions.push_back(FPoint3{ std::stof(x), std::stof(y), std::stof(z) });
}

void ObjParser::StoreFace(std::stringstream& face)
{
	// faces are laid out like this:
	// f v1[/ vt1][/ vn1] v2[/ vt2][/ vn2] v3[/ vt3][/ vn3]
	std::string first{}, second{}, third{}; // first being v, second being vt, third being vn
	GetFirstSecondThird(face, first, second, third);
	// first now contains v1/vt1/vn1
	// second now contains v2/vt2/vn2
	// third now contains v3/vt3/vn3

	const std::string* faces[3]{ &first, &second, &third };

	std::vector<int> faceIndexes{};
	faceIndexes.reserve(3); // atleast 3 indexes (max 9?)

	std::string index{};
	for (int i{}; i < 3; ++i)
	{
		size_t slashPos{};
		std::stringstream temp{ *faces[i] }; // all 3 strings
		do
		{
			std::getline(temp, index, '/'); // all indexes, delimited by a '/' (slash) ((!IF POSSIBLE!))
			faceIndexes.push_back(std::stoi(index) - 1); // !!!MINUS ONE SINCE OBJ STARTS AT 1 INSTEAD OF 0!!!
			slashPos = faces[i]->find('/', slashPos + 1);
			// using i as index, still using current faces[i] in this loop
			// if there's no delimiter, break off operation after having stored the first face element (there HAS to be atleast 1)
			if (slashPos == std::string::npos)
				break; // no slash found, meaning only 1 face, break loop and onto next face[++i]
			//woah I wrote this in november 2019 and I am able to reuse this code in July 2020, such a great student I am xd
			temp = std::stringstream{ faces[i]->substr(slashPos + 1) }; // create new substring from faces
		} while (true); // while (slashPos != std::string::npos) could also be used, but performance boost by adding if statement and break
	}

	const size_t size{ faceIndexes.size() };
	for (size_t idx{}; idx < size; ++idx)
	{
		size_t temp{ idx % (size / 3) };
		switch (temp)
		{
		case 0: // first face is an index in the indexbuffer
			m_PositionIndices.push_back(faceIndexes[idx]);
			break;
		case 1: // second face is a uv index
			m_UVIndices.push_back(faceIndexes[idx]);
			break;
		case 2: // third face is a normal index
			m_NormalIndices.push_back(faceIndexes[idx]);
			break;
		}
	}
}

void ObjParser::StoreNormal(std::stringstream& normal)
{
	std::string first{}, second{}, third{};
	GetFirstSecondThird(normal, first, second, third);
	m_Normals.push_back(GetNormalized(FVector3{ std::stof(first), std::stof(second), std::stof(third) }));
}

void ObjParser::StoreUV(std::stringstream& uv)
{
	std::string first{}, second{}, third{};
	GetFirstSecondThird(uv, first, second, third); // third will always be 0.000
	float y{ std::stof(second) };
	if (m_IsYAxisInverted) y = 1 - y; // invert Y-axis, bc screen (0, 0) is at the top left but a textures (0, 0) is at the bottom left
	m_UVs.push_back(FVector2{ std::stof(first), y });
}

void ObjParser::GetFirstSecondThird(std::stringstream& fst, std::string& first, std::string& second, std::string& third)
{
	// fst is laid out like this:
	// 1.000 2.000 3.000
	// first being 1.000, second being 2.000 third being 3.000
	std::getline(fst, first, ' ');
	// first now contains 1.000
	std::getline(fst, second, ' ');
	// second now contains 2.000
	std::getline(fst, third, ' ');
	// third now contains 3.000
}

void ObjParser::AssignVertices()
{
	m_Vertices.clear();
	m_Vertices.reserve(m_Positions.size());

	int indexCounter{};
	std::vector<Indexed> blackList{};


	for (size_t i{}; i < m_PositionIndices.size(); ++i) // every possible face
	{
		bool isUnique{ true };
		Indexed index{};

		for (Indexed& bl : blackList) // check for blacklisted vertices
		{
			if (bl.v == m_PositionIndices[i]) // v[?] == v[i]
			{
				// same vertex
				index.idx = bl.idx; // save indexCounter
				isUnique = false;
				break;
			}
		}

		if (isUnique)
		{
			m_Vertices.push_back(BaseVertex{ m_Positions[m_PositionIndices[i]] });
			index.v = m_PositionIndices[i]; index.idx = indexCounter;
			blackList.push_back(index);
			++indexCounter;
		}
		m_IndexBuffer.push_back(index.idx);
	}
}

const std::vector<BaseVertex> ObjParser::GetVertexBuffer() const
{
	return m_Vertices;
}

const std::vector<int> ObjParser::GetIndexBuffer() const
{
	return m_IndexBuffer;
}

void ObjParser::SetInvertYAxis(bool value)
{
	m_IsYAxisInverted = value;
}

bool ObjParser::OpenFile(const std::string& filePath)
{
	size_t posOfDot{ filePath.find('.') };
	if (posOfDot == std::string::npos) return false; // no initial value of filePath, means no dot, return false == no opening and no crash either
	if (filePath.substr(posOfDot) != ".obj") return false; // not a .obj file!

	if (m_ReadFile.is_open()) return false;

	m_ReadFile.open(filePath);
	return m_ReadFile.is_open();
}

void ObjParser::CloseFile()
{
	m_ReadFile.close();
}