#pragma once
#include <vector>
#include <string>
#include <fstream>
#include "EMath.h"
#include "EMathUtilities.h"

struct BaseVertex;
class ObjParser
{
public:
	ObjParser();
	ObjParser(const std::string& filePath);
	~ObjParser();

	bool OpenFile(const std::string& filePath);
	void CloseFile();

	void ReadFromObjFile();
	void ReadFromObjFile(const std::string& filePath);

	const std::vector<BaseVertex> GetVertexBuffer() const;
	const std::vector<int> GetIndexBuffer() const;

	void SetInvertYAxis(bool value);

private:
	std::ifstream m_ReadFile;

	void StorePosition(std::stringstream& position);
	void StoreFace(std::stringstream& face);
	void StoreNormal(std::stringstream& normal);
	void StoreUV(std::stringstream& uv);
	void GetFirstSecondThird(std::stringstream& fst, std::string& first, std::string& second, std::string& third);

	void AssignVertices();

	struct Indexed
	{
		int v{}, vt{}, vn{};
		int idx{};
	};

	bool m_IsYAxisInverted;

	std::vector<BaseVertex> m_Vertices;
	std::vector<int> m_IndexBuffer;

	std::vector<Elite::FPoint3> m_Positions;
	std::vector<Elite::FVector2> m_UVs;
	std::vector<Elite::FVector3> m_Normals;
	std::vector<int> m_PositionIndices;
	std::vector<int> m_UVIndices;
	std::vector<int> m_NormalIndices;
};