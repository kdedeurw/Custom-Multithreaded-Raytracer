#pragma once
#include "Light.h"

class PointLight : public Light
{
public:
	explicit PointLight(const Elite::RGBColor& colour, float intensity, const Elite::FPoint3& position);
	virtual ~PointLight() = default;

	Elite::RGBColor GetBiradiance(const Elite::FPoint3& pointToShade) override;

	Elite::FVector3 GetDirection(const Elite::FPoint3& pointToShade) const override;

	virtual float GetLambertCosineLaw(const HitRecord& hitRecord) const override;

private:
	Elite::FPoint3 m_Position;
};