#pragma once
#include "Material.h"

struct SDL_Surface;
class Material_Texture : public Material
{
public:
	Material_Texture(const Elite::RGBColor& diffuseColour, float diffuseReflectance, const char* path);
	virtual ~Material_Texture();

	virtual Elite::RGBColor Shade(Object* pObject, const HitRecord& hitRecord, const Elite::FVector3& lightDir, const Elite::FVector3& viewDir) const;
	virtual Elite::RGBColor Sample(const Elite::FVector2& uv) const;
	virtual Elite::FVector2 GetObjectUV(Object* pObject, const HitRecord& hitRecord) const = 0;

protected:
	SDL_Surface* m_pSurface;
};