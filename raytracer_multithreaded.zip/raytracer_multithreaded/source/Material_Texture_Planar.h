#pragma once
#include "Material_Texture.h"
class Material_Texture_Planar final : public Material_Texture
{
public:
	Material_Texture_Planar(const Elite::RGBColor& diffuseColour, float diffuseReflectance, const char* path);
	~Material_Texture_Planar() = default;

	Elite::FVector2 GetObjectUV(Object* pObject, const HitRecord& hitRecord) const override;

private:
};