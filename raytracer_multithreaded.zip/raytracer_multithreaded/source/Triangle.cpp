#include "pch.h"
#include "Triangle.h"
#include "Ray.h"
#include "HitRecord.h"

using namespace Elite;

Triangle::Triangle(const FPoint3& point, Material* pMaterial, const FPoint3& v0, const FPoint3& v1, const FPoint3& v2, Cullmode cullMode, float rotSpeed)
	: Object{ point, pMaterial }
	, m_Cullmode{ cullMode }
	, m_V0{ v0 }
	, m_V1{ v1 }
	, m_V2{ v2 }
	, m_Normal{}
	, m_RotationSpeed{ rotSpeed }
	, m_Rotation{ FMatrix3::Identity() }
{
	FVector3 a{ v1 - v0 };
	FVector3 b{ v2 - v0 };
	m_Normal = GetNormalized(Cross(a, b));
}

bool Triangle::Hit(const Ray& ray, HitRecord& hitRecord) const
{
	//TODO:? improve performance
	const FPoint3 v0{ ((FMatrix4)m_Rotation * (FPoint4)m_V0) + (FVector4)m_Position };
	const FPoint3 v1{ ((FMatrix4)m_Rotation * (FPoint4)m_V1) + (FVector4)m_Position };
	const FPoint3 v2{ ((FMatrix4)m_Rotation * (FPoint4)m_V2) + (FVector4)m_Position };

	const FVector3 edgeA{ v1 - v0 };
	const FVector3 edgeB{ v2 - v1 };
	const FVector3 n{ GetNormalized(Cross(edgeA, edgeB)) };
	// area is Cross/2

	const float dotVN{ Dot(ray.direction, n) };
	if (dotVN == 0)
		return false;

	if (m_Cullmode != Cullmode::noculling)
	{
		//Back-face
		if (dotVN > 0 && m_Cullmode == Cullmode::backface)
			return false;// distibutive property, so dotVN == dotNV
		//Front-face
		else if (dotVN < 0 && m_Cullmode == Cullmode::frontface)
			return false;
	}

	const FPoint3 center{ FPoint3{ ((FVector3)v0 + (FVector3)v1 + (FVector3)v2) / 3.f } };
	const FVector3 L{ center - ray.origin };

	const float t{ Dot(L, n) / dotVN };
	if (t < RayData::tMin || t > RayData::tMax)
		return false;

	const FPoint3 p{ ray.origin + t * ray.direction };

	FVector3 cVec{ p - v0 };
	const float a{ Dot(n, Cross(edgeA, cVec)) };
	if (a < 0)
		return false;

	cVec = { p - v1 };
	const float b{ Dot(n, Cross(edgeB, cVec)) };
	if (b < 0)
		return false;

	const FVector3 edgeC{ v0 - v2 };
	cVec = { p - v2 };
	const float c{ Dot(n, Cross(edgeC, cVec)) };
	if (c < 0)
		return false;

	hitRecord.t = t;
	hitRecord.point = ray.origin + t * ray.direction;
	hitRecord.normal = n;
	hitRecord.pMaterial = m_pMaterial;
	return true;
}

void Triangle::Update(float deltaTime)
{
	m_Rotation *= MakeRotationY(m_RotationSpeed * deltaTime);
	//TODO?: update duplicate vectors accordingly
}