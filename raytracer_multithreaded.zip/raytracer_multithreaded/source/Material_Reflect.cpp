#include "pch.h"
#include "Material_Reflect.h"
#include "SceneManager.h"
#include "SceneGraph.h"
#include "Ray.h"
#include "HitRecord.h"
#include "Object.h"

using namespace Elite;

Material_Reflect::Material_Reflect(const Elite::RGBColor& diffuseColour, float diffuseReflectance)
	: Material{ diffuseColour, diffuseReflectance }
{}

Elite::RGBColor Material_Reflect::Shade(Object* pObject, const HitRecord& hitRecord, const Elite::FVector3& lightDir, const Elite::FVector3& viewDir) const
{
	Ray reflect = Ray{ hitRecord.point, hitRecord.normal };
	HitRecord closestHit{}, currHit{};
	closestHit.t = RayData::tMax;
	Object* pCurrObject{};
	for (Object* pOtherObject : SceneManager::GetInstance()->GetSceneGraph()->GetObjects())
	{
		if (pOtherObject->Hit(reflect, currHit))
		{
			if (closestHit.t > currHit.t)
			{
				closestHit = currHit;
				pCurrObject = pOtherObject;
			}
		}
	}

	if (!closestHit.pMaterial)
		return RGBColor{};

	return closestHit.pMaterial->Shade(pCurrObject, closestHit, lightDir, viewDir);
}