#include "pch.h"
#include "Object.h"

using namespace Elite;

Object::Object(const FPoint3& pos, Material* pMaterial, float rotSpeed)
	: m_Position{ pos }
	, m_pMaterial{ pMaterial }
{}

Object::~Object()
{
	m_pMaterial = nullptr;
}

Material* Object::GetMaterial() const
{
	return m_pMaterial;
}

const Elite::FPoint3& Object::GetPosition() const
{
	return m_Position;
}