#include "pch.h"
#include "TextureManager.h"
#include "Texture.h"

TextureManager::~TextureManager()
{
	for (const std::pair<std::string, Texture*>& it : m_pTextures)
	{
		delete it.second;
	}
	m_pTextures.clear();
}

void TextureManager::StoreTexture(const std::string& name, Texture* pTexture)
{
	if (m_pTextures.find(name) == m_pTextures.end())
		m_pTextures.insert({name, pTexture});
}

void TextureManager::StoreTexture(const std::string& name, const std::string& path)
{
	if (m_pTextures.find(name) == m_pTextures.end())
		m_pTextures.insert({ name, new Texture{ path.c_str() } });
}

Texture* TextureManager::GatherTexture(const std::string& name)
{
	const auto it = m_pTextures.find(name);
	if (it != m_pTextures.end())
			return it->second;
	return nullptr;
}