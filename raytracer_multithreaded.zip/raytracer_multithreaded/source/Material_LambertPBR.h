#pragma once
#include "Material_Lambert.h"

class Material_LambertPBR : public Material_Lambert
{
public:
	Material_LambertPBR(const Elite::RGBColor& diffuseColour, float reflectance, const Elite::RGBColor& albedo, float roughness, bool isMetal);
	~Material_LambertPBR() = default;

	virtual Elite::RGBColor Shade(Object* pObject, const HitRecord& hitRecord, const Elite::FVector3& lightDir, const Elite::FVector3& viewDir) const override;

private:
	bool m_IsMetal;
	float m_Roughness;
	Elite::RGBColor m_Albedo;
	static const Elite::RGBColor m_Dielectric;

	struct BFD
	{
		static BFD CalculateBFD(const Elite::RGBColor& f0, const Elite::FVector3& halfVector, const Elite::FVector3& normal, const Elite::FVector3& lightDir, const Elite::FVector3& viewDir, float roughness2)
		{
			BFD bfd;
			bfd.B = GetNormalDistribution(halfVector, normal, lightDir, viewDir, roughness2);
			bfd.F = GetFresnel(f0, halfVector, viewDir);
			bfd.D = GetGeometry(normal, lightDir, viewDir, roughness2);
			return std::move(bfd);
		}

		static float GetNormalDistribution(const Elite::FVector3& halfVector, const Elite::FVector3& normal, const Elite::FVector3& lightDir, const Elite::FVector3& viewDir, float roughness2)
		{
			// Trowbridge-Reitz GGX / D
			const float dotNH = Dot(normal, halfVector);
			const float roughness4{ roughness2 * roughness2 };
			return roughness4 / (float(E_PI) * powf(((dotNH * dotNH) * (roughness4 - 1) + 1), 2.f));
		}

		static Elite::RGBColor GetFresnel(const Elite::RGBColor& f0, const Elite::FVector3& halfVector, const Elite::FVector3& viewDir)
		{
			// Fresnel / F
			return (f0 + (Elite::RGBColor{ 1.f, 1.f, 1.f } - f0) * (powf((1.f - Dot(halfVector, viewDir)), 5.f)));
		}

		static float GetGeometry(const Elite::FVector3& normal, const Elite::FVector3& lightDir, const Elite::FVector3& viewDir, float roughness2)
		{
			// Schlick-GGX / G
			const float dotNV = Dot(normal, viewDir);
			const float dotNL = Dot(normal, lightDir);
			const float squared{ powf(float{roughness2 + 1.f}, 2.f) };
			const float kDirect = squared / 8.f;
			const float geometryMasking = dotNV / (dotNV * (1.f - kDirect) + kDirect);
			const float geometryShadowing = dotNL / (dotNL * (1.f - kDirect) + kDirect);
			return geometryShadowing * geometryMasking;
		}

		float B;
		float D;
		Elite::RGBColor F;
	};
};

