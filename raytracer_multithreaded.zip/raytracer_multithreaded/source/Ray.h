#pragma once

#include "EMath.h"
#include "EMathUtilities.h"

namespace RayData
{
	static const float tMin = 0.0001f;
	static const float tMax = FLT_MAX;
}

struct Ray
{
	Ray(const Elite::FPoint3& origin, const Elite::FVector3& direction)
		: origin{origin}
		, direction{direction}
	{}

	Elite::FPoint3 origin{};
	Elite::FVector3 direction{};
};