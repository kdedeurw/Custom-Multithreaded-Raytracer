#pragma once
#include "Object.h"

class Triangle : public Object
{
public:
	enum class Cullmode
	{
		backface,
		frontface,
		noculling
	};

	explicit Triangle(const Elite::FPoint3& point, Material* pMaterial, const Elite::FPoint3& v0, const Elite::FPoint3& v1, const Elite::FPoint3& v2, Cullmode cullMode = Cullmode::noculling, float rotSpeed = 0.f);
	~Triangle() = default;

	virtual bool Hit(const Ray& ray, HitRecord& hitRecord) const override;

	virtual void Update(float deltaTime) override;

private:
	float m_RotationSpeed;
	Cullmode m_Cullmode;
	Elite::FPoint3 m_V0, m_V1, m_V2;
	Elite::FVector3 m_Normal;
	Elite::FMatrix3 m_Rotation;
	//TODO?: make duplicate v0, v1, v2 and normal
};