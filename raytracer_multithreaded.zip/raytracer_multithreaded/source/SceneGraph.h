#pragma once
#include <vector>

class Object;
class Light;
class SceneGraph
{
public:
	SceneGraph();
	~SceneGraph();

	void Update(float deltaTime);

	Object* AddObject(Object* pObject);
	Light* AddLight(Light* pLight);

	const std::vector<Object*>& GetObjects() const;
	const std::vector<Light*>& GetLights() const;

private:
	std::vector<Object*> m_pObjects;
	std::vector<Light*> m_pLights;
};