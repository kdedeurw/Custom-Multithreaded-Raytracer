/*=============================================================================*/
// Copyright 2017-2019 Elite Engine
// Authors: Matthieu Delaere
/*=============================================================================*/
// ERenderer.h: class that holds the surface to render to, does traverse the pixels 
// and traces the rays using a tracer
/*=============================================================================*/
#ifndef ELITE_RAYTRACING_RENDERER
#define	ELITE_RAYTRACING_RENDERER

#include <cstdint>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>

struct Ray;

struct SDL_Window;
struct SDL_Surface;

class Camera;
namespace Elite
{
	class Renderer final
	{
	public:
		Renderer(SDL_Window* pWindow, Camera* pCamera);
		~Renderer();

		Renderer(const Renderer&) = delete;
		Renderer(Renderer&&) noexcept = delete;
		Renderer& operator=(const Renderer&) = delete;
		Renderer& operator=(Renderer&&) noexcept = delete;

		//Renders on the same thread the application is run on
		void Render();
		bool SaveBackbufferToImage() const;

		//Uses multiple threads, owned by the render object
		void RenderMultithreaded();
		void StartThreads();
		void StopThreads();

	private:
		using uint = unsigned int;

		bool m_IsRendering;
		const int m_ThreadAmount = 4;
		uint m_Width;
		uint m_Height;
		SDL_Window* m_pWindow;
		SDL_Surface* m_pFrontBuffer;
		SDL_Surface* m_pBackBuffer;
		uint* m_pBackBufferPixels;
		Camera* m_pCamera;

		std::thread* m_pThreads;
		std::mutex m_Mutex;
		std::condition_variable m_ConditionVariable;
		std::atomic<int> m_ThreadsFinished;

		Ray GetCorrRay(float c, float r) const;

		//multithread test
		void RenderPartOfScreen(uint threadId, uint x, uint y, uint w, uint h);
	};
}

#endif