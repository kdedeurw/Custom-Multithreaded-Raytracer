#pragma once

#include "EMath.h"
#include "EMathUtilities.h"

#include "SDL.h"
#include "Ray.h"

class Camera
{
public:
	explicit Camera(const Elite::FPoint3& position, float fov);
	~Camera();

	const Elite::FVector3& GetRight();
	const Elite::FVector3& GetUp();
	const Elite::FVector3& GetForward(const Ray& ray);

	const Elite::FMatrix4& GenerateLookAt();
	const Elite::FMatrix3& GenerateRotation();
	Elite::FMatrix4 GetLookAtMatrixConst() const;

	float GetFov() const;
	const Elite::FPoint3& GetPos() const;

	const Elite::FPoint3& GetRayOrigin(const Elite::FPoint3& origin) const;

	void Rotate(Elite::FVector3& direction);

	void SetAspectRatio(float width, float height);
	float GetAspectRatio() const;

	void ProcessInputs(float deltaTime, bool lmb, bool rmb, bool mouse3);
	void ChangeSpeed(float value);

protected:
	float m_FOV; // works as the scalefactor here!
	float m_AspectRatio;
	float m_CameraSpeed = 10.f;

	Elite::FPoint3 m_Position{};

	Elite::FMatrix3 m_RotationMatrix;

	Elite::FVector3 m_Forward = { 0.f, 0.f, 1.f };
	const Elite::FVector3 m_WorldUp = { 0.f, 1.f, 0.f };
	Elite::FVector3 m_Up = { 0.f, 1.f, 0.f };
	Elite::FVector3 m_Right = { 1.f, 0.f, 0.f };
	Elite::FMatrix4 m_LookAt = { Elite::FVector4{m_Right, 0}, Elite::FVector4{m_Up, 0}, Elite::FVector4{m_Forward, 0}, Elite::FVector4{0, 0, 0, 1.f} };

	void TranslateX(float value);
	void TranslateY(float value);
	void TranslateZ(float value);

	void PrintCamSpeed();
};