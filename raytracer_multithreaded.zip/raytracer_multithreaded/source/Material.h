#pragma once
#include "ERGBColor.h"
#include "EMath.h"
#include "EMathUtilities.h"

struct HitRecord;
class Object;
class Material
{
public:
	Material(const Elite::RGBColor& diffuseColour, float diffuseReflectance);
	virtual ~Material() = default;

	virtual Elite::RGBColor Shade(Object* pObject, const HitRecord& hitRecord, const Elite::FVector3& lightDir, const Elite::FVector3& viewDir) const = 0;

protected:
	float m_DiffuseReflectance;
	Elite::RGBColor m_DiffuseColour;

	struct BRDF
	{
		static Elite::RGBColor Lambert(float diffuseReflectance, const Elite::RGBColor& diffuseColour)
		{
			const Elite::RGBColor p = diffuseColour * diffuseReflectance;
			return Elite::RGBColor{ p / float(E_PI) };
		}

		static Elite::RGBColor Lambert(const Elite::RGBColor& diffuseReflectance, const Elite::RGBColor& diffuseColour)
		{
			const Elite::RGBColor p = diffuseColour * diffuseReflectance;
			return Elite::RGBColor{ p / float(E_PI) };
		}

		static Elite::RGBColor Phong(float specularReflectance, float phongExponent, const Elite::FVector3& normal, const Elite::FVector3& lightDir, const Elite::FVector3& viewDir)
		{
			const Elite::FVector3 reflectV{ -lightDir + 2 * Dot(normal, lightDir) * normal };
			const float angle{ Dot(reflectV, viewDir) };
			const float phongSpecularReflection{ specularReflectance * powf(angle, float(phongExponent)) };
			return Elite::RGBColor{ phongSpecularReflection, phongSpecularReflection, phongSpecularReflection };
		}

		static Elite::RGBColor CookTorrance(const Elite::FVector3& normal, const Elite::FVector3& lightDir, const Elite::FVector3& viewDir, float D, const Elite::RGBColor& F, float G)
		{
			return Elite::RGBColor{ F * D * G / (4 * Dot(viewDir, normal) * Dot(lightDir, normal)) };
		}
	};
};