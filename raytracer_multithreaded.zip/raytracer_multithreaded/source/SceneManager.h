#pragma once
#include <vector>

class SceneGraph;
class SceneManager
{
public:
	static SceneManager* GetInstance()
	{
		if (!m_pSceneManager)
			m_pSceneManager = new SceneManager{};
		return m_pSceneManager;
	}
	~SceneManager();

	SceneGraph* AddSceneGraph(SceneGraph* pSceneGraph);
	const SceneGraph* GetSceneGraph() const;

	void Update(float deltaTime);

	void SwapSceneGraph();
	//J : enable / disable directional light
	//K � L : enable / disable left - right point light ???
	//Z : enable / disable hard shadows
	//T : toggle between Irradiance only, BRDF only and all combined. Lambert�s Cosine Law is always used.
	void ToggleDirectionalLights();
	void TogglePointLights();
	void ToggleHardShadows();
	void ToggleThatThing();

	enum class Toggle
	{
		Combined,
		Irradiance,
		BRDF,
	};

	bool IsDirLights() const { return m_EnableDirectionalLights; };
	bool IsPointLights() const { return m_EnablePointLights; };
	bool IsHardShadows() const { return m_EnableHardShadows; };
	Toggle ThatThing() const { return m_Toggle; };

private:
	static SceneManager* m_pSceneManager;
	SceneManager();

	//scenegraph could also only own this
	bool m_EnableDirectionalLights{}, m_EnablePointLights{};
	bool m_EnableHardShadows{};
	Toggle m_Toggle;
	int m_SceneIndex;
	std::vector<SceneGraph*> m_pSceneGraphs;
};
