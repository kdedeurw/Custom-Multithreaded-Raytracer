#include "pch.h"
#include "Camera.h"

#define _USE_MATH_DEFINES
#include <math.h>
#include <iostream>

#include "EventManager.h"

using namespace Elite;

Camera::Camera(const Elite::FPoint3& position, float fov)
	: m_FOV{ tanf(ToRadians(fov) / 2) }
	, m_AspectRatio{}
	, m_Forward{ 0, 0, 1.f }
	, m_Up{ 0, 1.f, 0 }
	, m_Right{ 1.f, 0, 0 }
	, m_LookAt{ Elite::FVector4{m_Right, 0}, Elite::FVector4{m_Up, 0}, Elite::FVector4{m_Forward, 0}, Elite::FVector4{0, 0, 0, 1.f} }
	, m_RotationMatrix{}
	, m_Position{ position }
{}

Camera::~Camera()
{}

void Camera::SetAspectRatio(float width, float height)
{
	m_AspectRatio = width / height;
}

float Camera::GetAspectRatio() const
{
	return m_AspectRatio;
}

float Camera::GetFov() const
{
	return m_FOV;
}

const FPoint3& Camera::GetPos() const
{
	return m_Position;
}

const FPoint3& Camera::GetRayOrigin(const FPoint3& origin) const
{
	static FVector4 temp{ Elite::FVector3{origin}, 1.f };
	//Then M* v is equal to
		//a b c d
		//M = e f g h
		//i j k l
		//m n o p

	static FVector4 calculated = { temp.x * m_LookAt.data[0][0] + temp.y * m_LookAt.data[0][1] + temp.z * m_LookAt.data[0][2] + temp.w * m_LookAt.data[0][3],
	temp.x* m_LookAt.data[1][0] + temp.y * m_LookAt.data[1][1] + temp.z * m_LookAt.data[1][2] + temp.w * m_LookAt.data[1][3],
	temp.x* m_LookAt.data[2][0] + temp.y * m_LookAt.data[2][1] + temp.z * m_LookAt.data[2][2] + temp.w * m_LookAt.data[2][3],
	temp.x* m_LookAt.data[3][0] + temp.y * m_LookAt.data[3][1] + temp.z * m_LookAt.data[3][2] + temp.w * m_LookAt.data[3][3] };
	
	//	And v* M is equal to
	//(x * a + y * e + z * i + w * m;
	//x * b + y * f + z * j + w * n;
	//x * c + y * g + z * k + w * o;
	//x * d + y * h + z * l + w * p)
	static FPoint3 rayOrigin{ calculated.x, calculated.y, calculated.z };
	return rayOrigin;
}

const FMatrix4& Camera::GenerateLookAt()
{
	m_LookAt = FMatrix4(GetRight(), GetUp(), m_Forward, FVector4(m_Position.x, m_Position.y, m_Position.z, 1.f));
	return m_LookAt;
}

const FMatrix3& Camera::GenerateRotation()
{
	m_RotationMatrix = FMatrix3(GetRight(), GetUp(), m_Forward);
	return m_RotationMatrix;
}

void Camera::Rotate(FVector3& direction)
{
	GenerateRotation();
	direction = m_RotationMatrix * direction;
}

FMatrix4 Camera::GetLookAtMatrixConst() const
{
	return FMatrix4{ FVector4{m_Right, 0}, FVector4{m_Up, 0}, FVector4{m_Forward, 0}, FVector4{FVector3{m_Position}, 1.f} };
}

const FVector3& Camera::GetRight()
{
	m_Right = Elite::Cross(FVector3{ 0, 1, 0 }, m_Forward);
	//Elite::Normalize(m_Right);
	return m_Right;
}

const FVector3& Camera::GetUp()
{
	m_Up = Elite::Cross(m_Forward, m_Right);
	//Elite::Normalize(m_Up);
	return m_Up;
}

const FVector3& Camera::GetForward(const Ray& ray)
{
	m_Forward = { m_Position - ray.origin };
	//Elite::Normalize(m_Forward);
	return m_Forward;
}

void Camera::TranslateX(float value) 
{
	m_Position += m_Right * value;
}

void Camera::TranslateY(float value)
{
	//m_Position += m_Up * value;
	m_Position += m_WorldUp * value;
}

void Camera::TranslateZ(float value)
{
	m_Position += m_Forward * value;
	//m_Position.z += MakeTranslation(m_Forward).data[3][2];
}

void Camera::ProcessInputs(float deltaTime, bool lmb, bool rmb, bool mouse3)
{
	const float limit{ 250.f };
	float x{}, y{};
	EventManager::GetInstance()->GetRelativeMouseValues(x, y);
	const Uint8* pStates = SDL_GetKeyboardState(nullptr);

	if (lmb && rmb)
	{
		TranslateY(y/50.f);
	}
	else if (lmb && !rmb)
	{
		TranslateZ(y/50.f);
		m_Forward = MakeRotationY(float(x)/limit) * m_Forward;
		//m_Forward = MakeRotation(float(y / limit)) * m_Forward;
	}
	else if (rmb && !lmb)
	{
		//FMatrix4 temp = MakeTranslation(m_Forward) * m_Position;
		//m_Position.x += MakeTranslation(m_Forward).data[3][0];
		//MakeRotation(x);
		//m_RotationMatrix;
		//MakeRotation(m_RotationMatrix);
		m_Forward = MakeRotationZYX(float(-y/limit), float(-x/limit), 0.f) * m_Forward;
		
		// !ROTATING AROUND FIXED POSITION!, seems like

		//MakeTranslation(FVector2{m_Position.x, m_Position.y}, );
	}

	if (pStates[SDL_SCANCODE_W])
	{
		TranslateZ(-m_CameraSpeed * deltaTime);
	}
	else if (pStates[SDL_SCANCODE_S])
	{
		TranslateZ(m_CameraSpeed * deltaTime);
	}
	if (pStates[SDL_SCANCODE_A])
	{
		TranslateX(-m_CameraSpeed * deltaTime);
	}
	else if (pStates[SDL_SCANCODE_D])
	{
		TranslateX(m_CameraSpeed * deltaTime);
	}

	GenerateLookAt();
}

void Camera::ChangeSpeed(float value)
{
	m_CameraSpeed += value;
	if (m_CameraSpeed < 0.f || m_CameraSpeed > 20.1f)
	{
		m_CameraSpeed -= value;
		std::cout << "\n!Exceeded speed!\n";
	}
	PrintCamSpeed();
}

void Camera::PrintCamSpeed()
{
	std::cout << "Cam Speed: " << m_CameraSpeed << '\n';
}