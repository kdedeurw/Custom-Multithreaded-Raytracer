#include "pch.h"
#include "Material.h"

using namespace Elite;

Material::Material(const RGBColor& diffuseColour, float diffuseReflectance)
	: m_DiffuseColour{ diffuseColour }
	, m_DiffuseReflectance{ diffuseReflectance }
{}