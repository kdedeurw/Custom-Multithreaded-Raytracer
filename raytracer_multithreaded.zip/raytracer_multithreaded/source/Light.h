#pragma once
#include "ERGBColor.h"
#include "EMath.h"
#include "EMathUtilities.h"

struct HitRecord;
class Light
{
public:
	explicit Light(const Elite::RGBColor& colour, float intensity);
	virtual ~Light() = default;

	virtual Elite::RGBColor GetBiradiance(const Elite::FPoint3& pointToShade) = 0;
	virtual Elite::FVector3 GetDirection(const Elite::FPoint3& pointToShade) const = 0;
	virtual float GetLambertCosineLaw(const HitRecord& hitRecord) const = 0;

protected:
	Elite::RGBColor m_Colour;
	float m_Intensity;
};