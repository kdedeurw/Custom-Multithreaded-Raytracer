#pragma once
#include "EMath.h"

struct BaseVertex
{
	explicit BaseVertex(const Elite::FPoint3& pos)
		: position{ pos }
	{}

	Elite::FPoint3 position;
};

struct AdvancedVertex : public BaseVertex
{
	explicit AdvancedVertex(const Elite::FPoint3& pos, const Elite::FPoint2& uv, const Elite::FPoint3& n, const Elite::FPoint3& t)
		: BaseVertex{ pos }
		, uv{ uv }
		, normal{ n }
		, tan{ t }
	{}

	Elite::FVector2 uv;
	Elite::FVector3 normal;
	Elite::FVector3 tan;
};